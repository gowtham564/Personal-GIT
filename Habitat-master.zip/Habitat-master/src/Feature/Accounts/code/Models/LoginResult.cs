﻿namespace Sitecore.Feature.Accounts.Models
{
  public class LoginResult
  {
    public string RedirectUrl { get; set; }
  }
}