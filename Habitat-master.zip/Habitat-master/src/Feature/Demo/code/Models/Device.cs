﻿namespace Sitecore.Feature.Demo.Models
{
  public class Device
  {
    public string Title { get; set; }
    public string Browser { get; set; }
  }
}