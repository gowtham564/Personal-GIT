﻿namespace Sitecore.Feature.Demo.Models
{
  using System;

  public class EngagementPlanState
  {
    public string EngagementPlanTitle { get; set; }
    public DateTime Date { get; set; }
    public string Title { get; set; }
  }
}