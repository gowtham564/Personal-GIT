﻿namespace Sitecore.Feature.Demo.Models
{
  public enum ProfilingTypes
  {
    Active,
    Historic
  }
}