﻿namespace Sitecore.Feature.Media.Models
{
  using Sitecore.Data.Items;

  public class MediaSelectorElement
  {
    public Item Item { get; set; }
    public string Active { get; set; }
  }
}