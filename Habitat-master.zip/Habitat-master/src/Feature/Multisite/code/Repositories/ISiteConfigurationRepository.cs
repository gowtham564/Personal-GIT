﻿namespace Sitecore.Feature.Multisite.Repositories
{
  using Sitecore.Feature.Multisite.Models;

  public interface ISiteConfigurationRepository
  {
    SiteConfigurations Get();
  }
}